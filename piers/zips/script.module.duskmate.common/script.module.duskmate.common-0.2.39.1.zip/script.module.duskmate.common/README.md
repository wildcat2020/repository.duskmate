# Duskmate Common

Duskmate-maintained fork of
[`jurialmunkey/script.module.jurialmunkey`](https://github.com/jurialmunkey/script.module.jurialmunkey).

This Kodi module provides shared Python support required by Duskmate Media
Helper. The fork retains the upstream `jurialmunkey` Python namespace so the
upstream-tracking helper can remain source-compatible while the installed Kodi
package and user-facing metadata use Duskmate branding.

Licensed under GPL-3.0-or-later. Upstream copyright and attribution are
retained.
