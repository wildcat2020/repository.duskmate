# -*- coding: utf-8 -*-
# Copyright: (c) 2019, Dag Wieers (@dagwieers) <dag@wieers.com>
# GNU General Public License v3.0 (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
''' This file implements the Kodi xbmc module, either using stubs or alternative functionality '''

# pylint: disable=invalid-name,no-self-use


import os
import json
import sys
import threading
import time
from weakref import WeakValueDictionary

from xbmcextra import __KODI_NEXUS__, global_settings, import_language

LOGFATAL = 'Fatal'
LOGERROR = 'Error'
LOGWARNING = 'Warning'
LOGNOTICE = 'Notice'
LOGINFO = 'Info'
LOGDEBUG = 'Debug'
LOGNONE = ''

INFO_LABELS = {
    'System.BuildVersion': '18.2',
}

REGIONS = {
    'datelong': '%A, %e %B %Y',
    'dateshort': '%Y-%m-%d',
}

GLOBAL_SETTINGS = global_settings()
PO = import_language(language=GLOBAL_SETTINGS.get('locale.language'))

PLAYLIST_VIDEO = 1
PLAYLIST_MUSIC = 0


class Keyboard:
    ''' A stub implementation of the xbmc Keyboard class '''

    def __init__(self, line='', heading=''):
        ''' A stub constructor for the xbmc Keyboard class '''

    def doModal(self, autoclose=0):
        ''' A stub implementation for the xbmc Keyboard class doModal() method '''

    def isConfirmed(self):
        ''' A stub implementation for the xbmc Keyboard class isConfirmed() method '''
        return True

    def getText(self):
        ''' A stub implementation for the xbmc Keyboard class getText() method '''
        return 'test'


class Monitor:
    ''' A stub implementation of the xbmc Monitor class '''

    __slots__ = ('__weakref__', )

    _instances = WeakValueDictionary()
    _aborted = threading.Event()

    def __new__(cls):
        ''' A stub constructor for the xbmc Monitor class '''

        self = super().__new__(cls)

        if not cls._instances:
            abort_timer = threading.Thread(target=self._timer)  # pylint: disable=protected-access
            abort_timer.daemon = True
            abort_timer.start()

        key = id(self)
        cls._instances[key] = self
        return self

    def __del__(self):
        key = id(self)
        if key in Monitor._instances:
            del Monitor._instances[key]

    def _timer(self):
        abort_time = 120 if __KODI_NEXUS__ else 90
        log('Test exit in {0}s'.format(abort_time), LOGINFO)

        Monitor._aborted.wait(abort_time)
        Monitor._aborted.set()
        try:
            sys.exit()
        except SystemExit:
            pass

    def abortRequested(self):
        ''' A stub implementation for the xbmc Monitor class abortRequested() method '''
        return Monitor._aborted.is_set()

    def waitForAbort(self, timeout=None):
        ''' A stub implementation for the xbmc Monitor class waitForAbort() method '''
        try:
            Monitor._aborted.wait(timeout)
        except KeyboardInterrupt:
            Monitor._aborted.set()
            try:
                sys.exit()
            except SystemExit:
                pass
        except SystemExit:
            Monitor._aborted.set()

        return Monitor._aborted.is_set()


class _KodiPlayerType(type):
    ''' Like Kodi 22, refuse to assign class attributes of a Player subclass (tests may still patch Player) '''

    def __setattr__(cls, name, value):
        if not cls.__dict__.get('_kodi_base'):
            raise AttributeError("cannot modify read-only attribute '%s.%s'" % (cls.__name__, name))
        super().__setattr__(name, value)


class Player(metaclass=_KodiPlayerType):
    ''' A stub implementation of the xbmc Player class '''
    _kodi_base = True

    def __init__(self):
        ''' A stub constructor for the xbmc Player class '''
        self._count = 0

    def play(self, item='', listitem=None, windowed=False, startpos=-1):  # pylint: disable=unused-argument
        ''' A stub implementation for the xbmc Player class play() method '''
        return

    def playnext(self):
        ''' A stub implementation for the xbmc Player class playnext() method '''
        return

    def stop(self):
        ''' A stub implementation for the xbmc Player class stop() method '''
        return

    def isExternalPlayer(self):
        ''' A stub implementation for the xbmc Player class isExternalPlayer() method '''
        return False

    def getPlayingFile(self):
        ''' A stub implementation for the xbmc Player class getPlayingFile() method '''
        return '/foo/bar'

    def isPlayingVideo(self):
        ''' A stub implementation for the xbmc Player class isPlayingVideo() method '''
        return True

    def pause(self):
        ''' A stub implementation for the xbmc Player class pause() method '''

    def isPlaying(self):
        ''' A stub implementation for the xbmc Player class isPlaying() method '''
        # Return True four times out of five
        self._count += 1
        return bool(self._count % 5 != 0)

    def seekTime(self, seekTime):  # pylint: disable=unused-argument
        ''' A stub implementation for the xbmc Player class seekTime() method '''
        return

    def showSubtitles(self, bVisible):  # pylint: disable=unused-argument
        ''' A stub implementation for the xbmc Player class showSubtitles() method '''
        return

    def getTotalTime(self):
        ''' A stub implementation for the xbmc Player class getTotalTime() method '''
        return 0

    def getTime(self):
        ''' A stub implementation for the xbmc Player class getTime() method '''
        return 0

    def getVideoInfoTag(self):
        ''' A stub implementation for the xbmc Player class getVideoInfoTag() method '''
        return VideoInfoTag()


class PlayList:
    ''' A stub implementation of the xbmc PlayList class '''

    def __init__(self):
        ''' A stub constructor for the xbmc PlayList class '''

    def getposition(self):
        ''' A stub implementation for the xbmc PlayList class getposition() method '''
        return 0

    def size(self):
        ''' A stub implementation for the xbmc PlayList class size() method '''


class VideoInfoTag:
    ''' A stub implementation of the xbmc VideoInfoTag class '''

    def __init__(self):
        ''' A stub constructor for the xbmc VideoInfoTag class '''

    def getSeason(self):
        ''' A stub implementation for the xbmc VideoInfoTag class getSeason() method '''
        return 0

    def getEpisode(self):
        ''' A stub implementation for the xbmc VideoInfoTag class getEpisode() method '''
        return 0

    def getTVShowTitle(self):
        ''' A stub implementation for the xbmc VideoInfoTag class getTVShowTitle() method '''
        return ''

    def getPlayCount(self):
        ''' A stub implementation for the xbmc VideoInfoTag class getPlayCount() method '''
        return 0

    def getRating(self):
        ''' A stub implementation for the xbmc VideoInfoTag class getRating() method '''
        return 0


def executebuiltin(string, wait=False):  # pylint: disable=unused-argument
    ''' A stub implementation of the xbmc executebuiltin() function '''
    return


def executeJSONRPC(jsonrpccommand):
    ''' A reimplementation of the xbmc executeJSONRPC() function '''
    command = json.loads(jsonrpccommand)
    if command.get('method') == 'Settings.GetSettingValue':
        key = command.get('params').get('setting')
        return json.dumps(dict(id=1, jsonrpc='2.0', result=dict(value=GLOBAL_SETTINGS.get(key))))
    if command.get('method') == 'Addons.GetAddonDetails':
        if command.get('params', {}).get('addonid') == 'script.module.inputstreamhelper':
            return json.dumps(dict(id=1, jsonrpc='2.0', result=dict(addon=dict(enabled='true', version='0.3.5'))))
        return json.dumps(dict(id=1, jsonrpc='2.0', result=dict(addon=dict(enabled='true', version='1.2.3'))))
    if command.get('method') == 'Textures.GetTextures':
        return json.dumps(dict(id=1, jsonrpc='2.0', result=dict(textures=[dict(cachedurl="", imagehash="", lasthashcheck="", textureid=4837, url="")])))
    if command.get('method') == 'Textures.RemoveTexture':
        return json.dumps(dict(id=1, jsonrpc='2.0', result="OK"))
    log("executeJSONRPC does not implement method '{method}'".format(**command), 'Error')
    return json.dumps(dict(error=dict(code=-1, message='Not implemented'), id=1, jsonrpc='2.0'))


def getCondVisibility(string):
    ''' A reimplementation of the xbmc getCondVisibility() function '''
    if string == 'system.platform.android':
        return False
    return True


def getInfoLabel(key):
    ''' A reimplementation of the xbmc getInfoLabel() function '''
    return INFO_LABELS.get(key)


def getLocalizedString(msgctxt):
    ''' A reimplementation of the xbmc getLocalizedString() function '''
    for entry in PO:
        if entry.msgctxt == '#%s' % msgctxt:
            return entry.msgstr or entry.msgid
    if int(msgctxt) >= 30000:
        log('Unable to translate #{msgctxt}'.format(msgctxt=msgctxt), LOGERROR)
    return '<Untranslated>'


def getRegion(key):
    ''' A reimplementation of the xbmc getRegion() function '''
    return REGIONS.get(key)


def log(msg, level):
    ''' A reimplementation of the xbmc log() function '''
    if level in ('Error', 'Fatal'):
        print('\033[31;1m%s: \033[32;0m%s\033[39;0m' % (level, msg))
        if level == 'Fatal':
            raise Exception(msg)
    elif level in ('Warning', 'Notice'):
        print('\033[33;1m%s: \033[32;0m%s\033[39;0m' % (level, msg))
    elif level == 'Debug':
        print('\033[32;1m%s: \033[30;1m%s\033[39;0m' % (level, msg))
    else:
        print('\033[32;1m%s: \033[32;0m%s\033[39;0m' % (level, msg))


def setContent(self, content):  # pylint: disable=unused-argument
    ''' A stub implementation of the xbmc setContent() function '''
    return


def sleep(seconds):
    ''' A reimplementation of the xbmc sleep() function '''
    time.sleep(seconds)


def translatePath(path):
    ''' A stub implementation of the xbmc translatePath() function '''
    if path.startswith('special://home'):
        return path.replace('special://home', os.path.join(os.getcwd(), 'tests/'))
    if path.startswith('special://masterprofile'):
        return path.replace('special://masterprofile', os.path.join(os.getcwd(), 'tests/userdata/'))
    if path.startswith('special://profile'):
        return path.replace('special://profile', os.path.join(os.getcwd(), 'tests/userdata/'))
    if path.startswith('special://userdata'):
        return path.replace('special://userdata', os.path.join(os.getcwd(), 'tests/userdata/'))
    return path
