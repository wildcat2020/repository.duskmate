from duskmate_sync_tvdb.provider import Provider
