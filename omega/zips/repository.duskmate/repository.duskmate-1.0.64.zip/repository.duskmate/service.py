"""One-shot deployment approved by installing the Duskmate repository ZIP."""

import hashlib
import json
import os
import sys
import xml.etree.ElementTree as ET
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

DUSKMATE_ANDROID_PACKAGE = "com.duskmate.tv"
DUSKMATE_RETURN_URI = "expansionkit://open"
DUSKMATE_LAUNCHER_PACKAGE = "com.duskmate.launcher"


def return_to_duskmate():
    """Return to the existing Duskmate task through its exported TV deep link.

    Some Google TV builds do not resolve a package-only StartAndroidActivity call to a
    Leanback activity consistently.  The explicit VIEW URI is handled by MainActivity and,
    with no title id, deliberately preserves whichever Duskmate screen was already open.
    """
    xbmc.executebuiltin(
        "StartAndroidActivity({},android.intent.action.VIEW,,{})".format(
            DUSKMATE_ANDROID_PACKAGE,
            DUSKMATE_RETURN_URI,
        )
    )


def return_to_package(package):
    if package == DUSKMATE_ANDROID_PACKAGE:
        return_to_duskmate()
    else:
        xbmc.executebuiltin("StartAndroidActivity({})".format(package))


ADDONS = (
    ("skin.duskmate", "0.3.5"),
    ("plugin.video.duskmate", "6.21.5.31"),
    ("service.duskmate.upnext", "1.4.1.1"),
)
EMBEDDED_DEPENDENCIES = (
    ("script.module.duskmate.infotagger", "0.1.0.2"),
    ("script.module.duskmate.common", "0.2.39.2"),
)
OFFICIAL_DEPENDENCIES = (
    ("script.module.requests", "2.9.1"),
    ("script.module.pil", "1.1.7"),
    ("script.module.addon.signals", "0.0.6"),
    ("script.module.qrcode", "6.1.0"),
)
TRAKT_ADDON = ("script.module.duskmate.sync.trakt", "1.2.9.11")
MARKER = xbmcvfs.translatePath(
    "special://profile/addon_data/repository.duskmate/bootstrap-1.0.64.done"
)
RUNNING_PROPERTY = "Duskmate.RepositoryDeploymentRunning.1.0.64"
PACKAGE_HASHES = {
    ("plugin.video.duskmate", "6.21.5.31"): "023cea485fc7aacbade235de69fe610525eb621338057a61cd579d147e945bc1",
    ("script.module.duskmate.sync.trakt", "1.2.9.11"): "3e0533e549be759378c6d8a944724341db4a5c50481b0b614d9f1df995fe2509",
    ("skin.duskmate", "0.3.5"): "c798a2c97bd7f98d3c2cd837ca428af020d0b0afc08d39d2f66834bd6541f983",
    # Filled from the deterministic repository build before publication.
    ("service.duskmate.upnext", "1.4.1.1"): "4317cf36b0463b61e5c511e81ac48ec7347dbf23a7c964cad0b4c4d686dcda12",
    ("script.module.duskmate.infotagger", "0.1.0.2"): "182cf811d2b7a9788f92e282469f344ab271f0fe23c7fe03637eccf8996ea236",
    ("script.module.duskmate.common", "0.2.39.2"): "2bb9c19f96572426d872ff3ce2f633b9ff6df1b82f866a3b09e624acc51a74b1",
}


def installed(addon_id):
    return xbmc.getCondVisibility("System.HasAddon({})".format(addon_id))


def json_rpc(method, params):
    """Run a Kodi JSON-RPC mutation and accept only an explicit successful result."""
    response = json.loads(xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0",
        "id": 1,
        "method": method,
        "params": params,
    })))
    return "error" not in response and response.get("result") is not None


def enable_addon(addon_id):
    # EnableAddon is not a supported built-in on all Kodi 21/22 builds. The JSON-RPC method is
    # stable, reports failure, and avoids treating an extracted-but-disabled package as ready.
    return json_rpc("Addons.SetAddonEnabled", {"addonid": addon_id, "enabled": True})


def installed_version(addon_id):
    addon_xml = xbmcvfs.translatePath(
        "special://home/addons/{}/addon.xml".format(addon_id)
    )
    try:
        # Both System.HasAddon and xbmcaddon.Addon can reject a disabled add-on. Its local
        # manifest remains authoritative and lets migrations identify the installed version.
        metadata = ET.parse(addon_xml).getroot()
        if metadata.attrib.get("id") == addon_id:
            return metadata.attrib.get("version", "")
    except (ET.ParseError, OSError):
        pass
    try:
        return xbmcaddon.Addon(addon_id).getAddonInfo("version")
    except RuntimeError:
        return ""


def ready(addon_id, expected_version):
    # A freshly extracted add-on can already have a readable addon.xml while Kodi has not
    # registered or enabled it yet. Treating that state as ready lets the bootstrapper race
    # ahead and leaves the helper and its renamed dependencies disabled on a clean install.
    return installed_version(addon_id) == expected_version and installed(addon_id)


def wait_for(addon_id, expected_version, monitor, seconds=180):
    for _ in range(seconds * 2):
        if ready(addon_id, expected_version):
            return True
        if monitor.waitForAbort(0.5):
            return False
    return False


def install_embedded(addon_id, current_version, expected_version, monitor):
    """Install or replace a pinned package from the repository's embedded payload."""
    expected_hash = PACKAGE_HASHES.get((addon_id, expected_version))
    if not current_version or not expected_hash:
        return False
    filename = "{}-{}.zip".format(addon_id, expected_version)
    archive_path = xbmcvfs.translatePath(
        "special://home/addons/repository.duskmate/payloads/{}".format(filename)
    )
    addons_path = os.path.realpath(xbmcvfs.translatePath("special://home/addons"))
    xbmc.log(
            "Duskmate repository: installing embedded {} from {} to {}".format(
            addon_id, current_version, expected_version
        ),
        xbmc.LOGINFO,
    )
    try:
        if not xbmcvfs.exists(archive_path):
            raise RuntimeError("embedded package is missing")
        digest = hashlib.sha256()
        with open(archive_path, "rb") as source:
            for block in iter(lambda: source.read(1024 * 1024), b""):
                digest.update(block)
        if digest.hexdigest() != expected_hash:
            raise RuntimeError("SHA-256 mismatch for downloaded package")
        prefix = addon_id + "/"
        with zipfile.ZipFile(archive_path, "r") as package:
            for member in package.infolist():
                name = member.filename.replace("\\", "/")
                target = os.path.realpath(os.path.join(addons_path, *name.split("/")))
                if not name.startswith(prefix) or os.path.commonpath((addons_path, target)) != addons_path:
                    raise RuntimeError("unsafe package path")
            package.extractall(addons_path)
        # UpdateLocalAddons is asynchronous. On Android TV, an enable request sent immediately after
        # extraction is often ignored because the new id is not in Kodi's add-on database yet.
        # Refresh, retry the idempotent enable operation, and verify both version and enabled
        # state before moving to a dependent package.
        for _ in range(120):
            xbmc.executebuiltin("UpdateLocalAddons")
            enable_addon(addon_id)
            if ready(addon_id, expected_version):
                return True
            if monitor.waitForAbort(0.25):
                return False
        raise RuntimeError("Kodi did not register and enable the extracted package")
    except Exception as exc:  # Kodi must keep running and report a useful installer error.
        xbmc.log(
            "Duskmate repository: embedded installation failed for {}: {}".format(addon_id, exc),
            xbmc.LOGERROR,
        )
        return False


def install(addon_id, expected_version, monitor):
    current = installed_version(addon_id) or "not installed"
    xbmc.log(
        "Duskmate repository: installing/updating {} from {} to {}".format(
            addon_id, current, expected_version
        ),
        xbmc.LOGINFO,
    )
    return install_embedded(addon_id, current, expected_version, monitor)


def ensure_official_dependency(addon_id, minimum_version, monitor, seconds=90):
    """Install only dependencies distributed by Kodi's official repository."""
    if installed_version(addon_id):
        return True
    xbmc.log(
        "Duskmate repository: requesting official dependency {} >= {}".format(
            addon_id, minimum_version
        ),
        xbmc.LOGINFO,
    )
    xbmc.executebuiltin("InstallAddon({})".format(addon_id))
    for _ in range(seconds * 4):
        if installed_version(addon_id):
            return True
        # InstallAddon opens Kodi's native confirmation dialog on a clean profile. The viewer
        # already approved this exact dependency through Duskmate's package-specific Install
        # action. Confirm only DialogConfirm's affirmative control; never send a generic Select
        # to whichever Kodi window happens to be visible.
        if xbmc.getCondVisibility("Window.IsActive(yesnodialog)"):
            xbmc.executebuiltin("SendClick(10100,10)")
        if monitor.waitForAbort(0.25):
            return False
    return False


def activate_skin(monitor):
    """Activate only the pinned Duskmate skin and accept only Kodi's exact confirm dialog."""
    if xbmc.getSkinDir() == "skin.duskmate":
        return True
    if not enable_addon("skin.duskmate"):
        return False
    if not json_rpc("Settings.SetSettingValue", {
        "setting": "lookandfeel.skin",
        "value": "skin.duskmate",
    }):
        return False
    for _ in range(80):
        if xbmc.getCondVisibility("Window.IsActive(yesnodialog)"):
            # DialogConfirm control 10 is the affirmative button. SendClick targets that exact
            # window/control pair and cannot activate a different Kodi screen accidentally.
            xbmc.executebuiltin("SendClick(10100,10)")
        if xbmc.getSkinDir() == "skin.duskmate" and not xbmc.getCondVisibility("Window.IsActive(yesnodialog)"):
            return True
        if monitor.waitForAbort(0.25):
            return False
    return False


def _deploy(
    include_skin=False,
    include_helper=True,
    include_upnext=False,
    include_trakt=False,
    skin_only=False,
    return_package=DUSKMATE_ANDROID_PACKAGE,
):
    monitor = xbmc.Monitor()
    # Kodi leaves the Install-from-ZIP file browser open after the repository
    # has been approved. That modal blocks InstallAddon built-ins even while
    # Kodi is in the background, so close only that dialog before deployment.
    xbmc.executebuiltin("Dialog.Close(filebrowser,true)")
    monitor.waitForAbort(0.5)
    xbmc.log("Duskmate repository: installing approved embedded packages", xbmc.LOGINFO)

    if skin_only:
        include_skin = True
        include_helper = False
        include_upnext = False

    if include_helper:
        # Kodi's native confirmation window is considered active only while Kodi's Android
        # activity owns the foreground. The caller deliberately brings Kodi forward for this
        # short, security-sensitive phase. Returning to Duskmate before InstallAddon finishes
        # leaves a hidden dialog that cannot be targeted by Window.IsActive on Android TV.
        for addon_id, minimum_version in OFFICIAL_DEPENDENCIES:
            if not ensure_official_dependency(addon_id, minimum_version, monitor):
                xbmc.log(
                    "Duskmate repository: official dependency unavailable: {}".format(addon_id),
                    xbmc.LOGERROR,
                )
                return

    # All Kodi-native confirmations are complete. Keep the viewer on Duskmate's progress screen
    # while the pinned, already-approved packages are installed and configured in the background.
    return_to_package(return_package)
    monitor.waitForAbort(1)

    # Preserve the product setup order approved by the viewer: visual integration first,
    # then the core media helper, followed by independently selected enhancements.
    packages = ()
    if include_skin:
        packages += (ADDONS[0],)
    if include_helper:
        packages += EMBEDDED_DEPENDENCIES + (ADDONS[1],)
    if include_upnext:
        packages += (ADDONS[2],)
    if include_trakt:
        packages += (TRAKT_ADDON,)
    for addon_id, expected_version in packages:
        if monitor.abortRequested():
            return
        if not ready(addon_id, expected_version):
            if not install(addon_id, expected_version, monitor):
                xbmc.log("Duskmate repository: installation timed out for {}".format(addon_id), xbmc.LOGERROR)
                return
        if not wait_for(addon_id, expected_version, monitor):
            xbmc.log("Duskmate repository: installation timed out for {}".format(addon_id), xbmc.LOGERROR)
            return
        # Kodi can retain a dependency on disk but leave it disabled after replacing a renamed
        # module. Enable every approved package even when its pinned files were already present,
        # then refresh local add-on metadata before the helper is first invoked.
        enable_addon(addon_id)
        xbmc.executebuiltin("UpdateLocalAddons")
        monitor.waitForAbort(0.25)
        if addon_id == "skin.duskmate" and not activate_skin(monitor):
            xbmc.log("Duskmate repository: Duskmate skin activation failed", xbmc.LOGERROR)
            return

    parent = os.path.dirname(MARKER)
    if not xbmcvfs.exists(parent):
        xbmcvfs.mkdirs(parent)
    marker = xbmcvfs.File(MARKER, "w")
    marker.write("complete\n")
    marker.close()
    xbmc.log(
        "Duskmate repository: approved deployment complete "
        "(helper={}, skin={}, upnext={}, trakt={})".format(
            include_helper, include_skin, include_upnext, include_trakt
        ),
        xbmc.LOGINFO,
    )


def deploy(
    force=False,
    include_skin=False,
    include_helper=True,
    include_upnext=False,
    include_trakt=False,
    skin_only=False,
    return_package=DUSKMATE_ANDROID_PACKAGE,
):
    if os.path.exists(MARKER) and not force:
        return

    window = xbmcgui.Window(10000)
    if window.getProperty(RUNNING_PROPERTY) == "true":
        return
    window.setProperty(RUNNING_PROPERTY, "true")
    try:
        _deploy(
            include_skin=include_skin,
            include_helper=include_helper,
            include_upnext=include_upnext,
            include_trakt=include_trakt,
            skin_only=skin_only,
            return_package=return_package,
        )
    finally:
        window.clearProperty(RUNNING_PROPERTY)
        # Kodi is the foreground app, so Android permits this hand-off even when Android would
        # reject a background activity launch made directly by Duskmate itself.
        return_to_package(return_package)


if __name__ == "__main__":
    if sys.argv and sys.argv[0].startswith("plugin://"):
        # Files.GetDirectory selects this extension deterministically and supplies a valid plugin
        # handle. Addons.ExecuteAddon is ambiguous for this repository/service/script/plugin and
        # can invoke the plugin extension without a directory handle, crashing Kodi when the
        # directory is closed. Keep every externally callable route on a plugin URL instead.
        # Kodi keeps the base plugin URL in argv[0] and the query string in argv[2].
        # Join the request pieces so routing works both for Files.GetDirectory and direct calls.
        plugin_request = " ".join([sys.argv[0]] + sys.argv[2:])
        if "return_launcher=1" in plugin_request:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=False)
            xbmc.Monitor().waitForAbort(0.25)
            xbmc.executebuiltin("StartAndroidActivity({})".format(DUSKMATE_LAUNCHER_PACKAGE))
        elif "setup_launcher=1" in plugin_request:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=False)
            # Run in this already-authorized plugin process. Queueing a second RunScript from a
            # Files.GetDirectory callback is dropped by some Android/Kodi builds after the plugin
            # directory closes, leaving the caller waiting forever with no deployment process.
            deploy(force=True, skin_only=True, return_package=DUSKMATE_LAUNCHER_PACKAGE)
        elif "return=1" in plugin_request:
            # Close the plugin directory before switching activities. Kodi serializes native
            # JSON-RPC work behind this call; leaving it open while Android pauses Kodi can pin
            # port 9090 until the process is restarted. The explicit VIEW deep link below is
            # immediate and does not need the old post-directory delay.
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=False)
            return_to_duskmate()
        else:
            skin = "skin=1" in plugin_request
            upnext = "upnext=1" in plugin_request
            trakt = "trakt=1" in plugin_request
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=False)
            deploy(
                force=True,
                include_skin=skin,
                include_upnext=upnext,
                include_trakt=trakt,
            )
    elif "return_launcher" in sys.argv[1:]:
        xbmc.executebuiltin("StartAndroidActivity({})".format(DUSKMATE_LAUNCHER_PACKAGE))
    elif "return" in sys.argv[1:]:
        # Kodi owns the foreground here, so Android allows this hand-off even on
        # TV firmware that blocks Duskmate from moving its own background task.
        return_to_duskmate()
    elif "force" in sys.argv[1:] or "trakt" in sys.argv[1:] or "skin" in sys.argv[1:]:
        # Deployment is an explicit user-approved setup action. The repository's login service
        # must remain passive: silently deploying on every new version marker races launcher and
        # app cold starts, changes the foreground, and can trigger concurrent Kodi plugin calls.
        launcher = "launcher" in sys.argv[1:]
        deploy(
            force="force" in sys.argv[1:],
            include_skin="skin" in sys.argv[1:],
            include_upnext="upnext" in sys.argv[1:],
            include_trakt="trakt" in sys.argv[1:],
            skin_only="skin" in sys.argv[1:],
            return_package=DUSKMATE_LAUNCHER_PACKAGE if launcher else DUSKMATE_ANDROID_PACKAGE,
        )
