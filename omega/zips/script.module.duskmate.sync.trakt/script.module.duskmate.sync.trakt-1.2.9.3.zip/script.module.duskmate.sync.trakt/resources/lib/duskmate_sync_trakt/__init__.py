from duskmate_sync_trakt.provider import Provider
