from duskmate_sync_mdblist.provider import Provider
