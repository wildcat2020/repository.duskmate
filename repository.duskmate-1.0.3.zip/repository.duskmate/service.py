"""One-shot deployment approved by installing the Duskmate repository ZIP."""

import os
import sys

import xbmc
import xbmcvfs


ADDONS = (
    "plugin.video.duskmate",
    "skin.duskmate",
)
MARKER = xbmcvfs.translatePath(
    "special://profile/addon_data/repository.duskmate/bootstrap-1.0.3.done"
)


def installed(addon_id):
    return xbmc.getCondVisibility("System.HasAddon({})".format(addon_id))


def wait_for(addon_id, monitor, seconds=180):
    for _ in range(seconds * 2):
        if installed(addon_id):
            return True
        if monitor.waitForAbort(0.5):
            return False
    return False


def deploy(force=False):
    if os.path.exists(MARKER) and not force:
        return

    monitor = xbmc.Monitor()
    xbmc.log("Duskmate repository: refreshing repository indexes", xbmc.LOGINFO)
    xbmc.executebuiltin("UpdateAddonRepos", wait=True)
    monitor.waitForAbort(4)

    for addon_id in ADDONS:
        if monitor.abortRequested():
            return
        if not installed(addon_id):
            xbmc.log("Duskmate repository: installing {}".format(addon_id), xbmc.LOGINFO)
            xbmc.executebuiltin("InstallAddon({})".format(addon_id), wait=True)
        if not wait_for(addon_id, monitor):
            xbmc.log("Duskmate repository: installation timed out for {}".format(addon_id), xbmc.LOGERROR)
            return

    parent = os.path.dirname(MARKER)
    if not xbmcvfs.exists(parent):
        xbmcvfs.mkdirs(parent)
    marker = xbmcvfs.File(MARKER, "w")
    marker.write("complete\n")
    marker.close()
    xbmc.log("Duskmate repository: helper and skin deployment complete", xbmc.LOGINFO)


if __name__ == "__main__":
    deploy(force="force" in sys.argv[1:])
