"""One-shot deployment approved by installing the Duskmate repository ZIP."""

import os
import sys

import xbmc
import xbmcgui
import xbmcvfs


ADDONS = (
    "plugin.video.duskmate",
    "script.module.duskmate.sync.trakt",
    "skin.duskmate",
)
MARKER = xbmcvfs.translatePath(
    "special://profile/addon_data/repository.duskmate/bootstrap-1.0.11.done"
)
RUNNING_PROPERTY = "Duskmate.RepositoryDeploymentRunning"


def installed(addon_id):
    return xbmc.getCondVisibility("System.HasAddon({})".format(addon_id))


def wait_for(addon_id, monitor, seconds=180):
    for _ in range(seconds * 2):
        if installed(addon_id):
            return True
        if monitor.waitForAbort(0.5):
            return False
    return False


def install(addon_id, monitor, seconds=360):
    xbmc.log("Duskmate repository: installing {}".format(addon_id), xbmc.LOGINFO)
    xbmc.executebuiltin("InstallAddon({})".format(addon_id))
    # Kodi resolves and downloads each add-on's complete dependency chain before
    # System.HasAddon becomes true. On slower Android TV hardware the helper and
    # skin can legitimately take several minutes, especially on the first run.
    for _ in range(seconds * 4):
        if installed(addon_id):
            return True
        if xbmc.getCondVisibility("Window.IsActive(yesnodialog)"):
            # InstallAddon deliberately focuses No. The viewer already approved this narrowly
            # scoped deployment with Duskmate's Install button, so accept Kodi's own dialog.
            xbmc.executebuiltin("Action(Left)")
            monitor.waitForAbort(0.25)
            xbmc.executebuiltin("Action(Select)")
        if monitor.waitForAbort(0.25):
            return False
    return False


def _deploy():
    monitor = xbmc.Monitor()
    # Kodi leaves the Install-from-ZIP file browser open after the repository
    # has been approved. That modal blocks InstallAddon built-ins even while
    # Kodi is in the background, so close only that dialog before deployment.
    xbmc.executebuiltin("Dialog.Close(filebrowser,true)")
    monitor.waitForAbort(0.5)
    # The repository service starts while Kodi owns the foreground, so Android permits this
    # immediate hand-off. Keep Duskmate's progress screen visible while Kodi performs the
    # approved installation in its background process.
    xbmc.executebuiltin("StartAndroidActivity(com.expansionkit.tv)")
    monitor.waitForAbort(1)
    xbmc.log("Duskmate repository: refreshing repository indexes", xbmc.LOGINFO)
    # Never wait on the repository refresh: Kodi can already be refreshing immediately after the
    # ZIP upgrade, and two synchronous refreshes deadlock each other on some Android builds.
    xbmc.executebuiltin("UpdateAddonRepos")
    monitor.waitForAbort(4)

    for addon_id in ADDONS:
        if monitor.abortRequested():
            return
        if not installed(addon_id):
            if not install(addon_id, monitor):
                xbmc.log("Duskmate repository: installation timed out for {}".format(addon_id), xbmc.LOGERROR)
                return
        if not wait_for(addon_id, monitor):
            xbmc.log("Duskmate repository: installation timed out for {}".format(addon_id), xbmc.LOGERROR)
            return

    parent = os.path.dirname(MARKER)
    if not xbmcvfs.exists(parent):
        xbmcvfs.mkdirs(parent)
    marker = xbmcvfs.File(MARKER, "w")
    marker.write("complete\n")
    marker.close()
    xbmc.log("Duskmate repository: helper, Trakt sync and skin deployment complete", xbmc.LOGINFO)


def deploy(force=False):
    if os.path.exists(MARKER) and not force:
        return

    window = xbmcgui.Window(10000)
    if window.getProperty(RUNNING_PROPERTY) == "true":
        return
    window.setProperty(RUNNING_PROPERTY, "true")
    try:
        _deploy()
    finally:
        window.clearProperty(RUNNING_PROPERTY)
        # Kodi is the foreground app, so Android permits this hand-off even when Android would
        # reject a background activity launch made directly by Duskmate itself.
        xbmc.executebuiltin("StartAndroidActivity(com.expansionkit.tv)")


if __name__ == "__main__":
    deploy(force="force" in sys.argv[1:])
