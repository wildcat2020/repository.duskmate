"""One-shot deployment approved by installing the Duskmate repository ZIP."""

import hashlib
import json
import os
import sys
import xml.etree.ElementTree as ET
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

DUSKMATE_ANDROID_PACKAGE = "com.duskmate.tv"
DUSKMATE_RETURN_URI = "expansionkit://open"
DUSKMATE_LAUNCHER_PACKAGE = "com.duskmate.launcher"


def return_to_duskmate():
    """Return to the existing Duskmate task through its exported TV deep link.

    Some Google TV builds do not resolve a package-only StartAndroidActivity call to a
    Leanback activity consistently.  The explicit VIEW URI is handled by MainActivity and,
    with no title id, deliberately preserves whichever Duskmate screen was already open.
    """
    xbmc.executebuiltin(
        "StartAndroidActivity({},android.intent.action.VIEW,,{})".format(
            DUSKMATE_ANDROID_PACKAGE,
            DUSKMATE_RETURN_URI,
        )
    )


def return_to_package(package):
    if package == DUSKMATE_ANDROID_PACKAGE:
        return_to_duskmate()
    else:
        xbmc.executebuiltin("StartAndroidActivity({})".format(package))


ADDONS = (
    ("skin.duskmate", "0.3.4"),
    ("plugin.video.duskmate", "6.21.5.29"),
    ("service.duskmate.upnext", "1.4.1.0"),
)
EMBEDDED_DEPENDENCIES = (
    ("script.module.infotagger", "0.1.0"),
    ("script.module.jurialmunkey", "0.2.37"),
)
OFFICIAL_DEPENDENCIES = (
    ("script.module.requests", "2.9.1"),
    ("script.module.pil", "1.1.7"),
    ("script.module.addon.signals", "0.0.6"),
    ("script.module.qrcode", "6.1.0"),
)
TRAKT_ADDON = ("script.module.duskmate.sync.trakt", "1.2.9.10")
MARKER = xbmcvfs.translatePath(
    "special://profile/addon_data/repository.duskmate/bootstrap-1.0.55.done"
)
RUNNING_PROPERTY = "Duskmate.RepositoryDeploymentRunning.1.0.55"
PACKAGE_HASHES = {
    ("plugin.video.duskmate", "6.21.5.29"): "41f5c8efe7aa61325a20c56bc1a84937f184358210f9c96683be6d1c5b30af7b",
    ("script.module.duskmate.sync.trakt", "1.2.9.10"): "8ba36e024cb41235e5d9b140942d9c37bac48aa31a6ea9d1a7296c5f1ae5bb68",
    ("skin.duskmate", "0.3.4"): "bf5b6a36837f84980b345df91fc14df8a92dca3bc70942f1d2af4c7156a48298",
    # Filled from the deterministic repository build before publication.
    ("service.duskmate.upnext", "1.4.1.0"): "1f0628c06401a56988210d186dc512501d0eebd8dfd75a1eab60000cc9d61a6b",
    ("script.module.infotagger", "0.1.0"): "582d75ef8ee1696524f1575fd1c71d0b9bbe012cbc2abacfd78012d38299d529",
    ("script.module.jurialmunkey", "0.2.37"): "07899d34aab626648a18066f962061669ef623ac4c92753817aa482ac7ca4b85",
}


def installed(addon_id):
    return xbmc.getCondVisibility("System.HasAddon({})".format(addon_id))


def installed_version(addon_id):
    addon_xml = xbmcvfs.translatePath(
        "special://home/addons/{}/addon.xml".format(addon_id)
    )
    try:
        # Both System.HasAddon and xbmcaddon.Addon can reject a disabled add-on. Its local
        # manifest remains authoritative and lets migrations identify the installed version.
        metadata = ET.parse(addon_xml).getroot()
        if metadata.attrib.get("id") == addon_id:
            return metadata.attrib.get("version", "")
    except (ET.ParseError, OSError):
        pass
    try:
        return xbmcaddon.Addon(addon_id).getAddonInfo("version")
    except RuntimeError:
        return ""


def ready(addon_id, expected_version):
    return installed_version(addon_id) == expected_version


def wait_for(addon_id, expected_version, monitor, seconds=180):
    for _ in range(seconds * 2):
        if ready(addon_id, expected_version):
            return True
        if monitor.waitForAbort(0.5):
            return False
    return False


def install_embedded(addon_id, current_version, expected_version, monitor):
    """Install or replace a pinned package from the repository's embedded payload."""
    expected_hash = PACKAGE_HASHES.get((addon_id, expected_version))
    if not current_version or not expected_hash:
        return False
    filename = "{}-{}.zip".format(addon_id, expected_version)
    archive_path = xbmcvfs.translatePath(
        "special://home/addons/repository.duskmate/payloads/{}".format(filename)
    )
    addons_path = os.path.realpath(xbmcvfs.translatePath("special://home/addons"))
    xbmc.log(
            "Duskmate repository: installing embedded {} from {} to {}".format(
            addon_id, current_version, expected_version
        ),
        xbmc.LOGINFO,
    )
    try:
        if not xbmcvfs.exists(archive_path):
            raise RuntimeError("embedded package is missing")
        digest = hashlib.sha256()
        with open(archive_path, "rb") as source:
            for block in iter(lambda: source.read(1024 * 1024), b""):
                digest.update(block)
        if digest.hexdigest() != expected_hash:
            raise RuntimeError("SHA-256 mismatch for downloaded package")
        prefix = addon_id + "/"
        with zipfile.ZipFile(archive_path, "r") as package:
            for member in package.infolist():
                name = member.filename.replace("\\", "/")
                target = os.path.realpath(os.path.join(addons_path, *name.split("/")))
                if not name.startswith(prefix) or os.path.commonpath((addons_path, target)) != addons_path:
                    raise RuntimeError("unsafe package path")
            package.extractall(addons_path)
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("EnableAddon({})".format(addon_id))
        return wait_for(addon_id, expected_version, monitor, seconds=30)
    except Exception as exc:  # Kodi must keep running and report a useful installer error.
        xbmc.log(
            "Duskmate repository: embedded installation failed for {}: {}".format(addon_id, exc),
            xbmc.LOGERROR,
        )
        return False


def install(addon_id, expected_version, monitor):
    current = installed_version(addon_id) or "not installed"
    xbmc.log(
        "Duskmate repository: installing/updating {} from {} to {}".format(
            addon_id, current, expected_version
        ),
        xbmc.LOGINFO,
    )
    return install_embedded(addon_id, current, expected_version, monitor)


def ensure_official_dependency(addon_id, minimum_version, monitor, seconds=90):
    """Install only dependencies distributed by Kodi's official repository."""
    if installed_version(addon_id):
        return True
    xbmc.log(
        "Duskmate repository: requesting official dependency {} >= {}".format(
            addon_id, minimum_version
        ),
        xbmc.LOGINFO,
    )
    xbmc.executebuiltin("InstallAddon({})".format(addon_id))
    for _ in range(seconds * 4):
        if installed_version(addon_id):
            return True
        if monitor.waitForAbort(0.25):
            return False
    return False


def activate_skin(monitor):
    """Activate only the pinned Duskmate skin and accept only Kodi's exact confirm dialog."""
    if xbmc.getSkinDir() == "skin.duskmate":
        return True
    request = json.dumps({
        "jsonrpc": "2.0",
        "id": 1,
        "method": "Settings.SetSettingValue",
        "params": {"setting": "lookandfeel.skin", "value": "skin.duskmate"},
    })
    response = json.loads(xbmc.executeJSONRPC(request) or "{}")
    if "error" in response:
        xbmc.log("Duskmate repository: skin activation failed: {}".format(response["error"]), xbmc.LOGERROR)
        return False
    for _ in range(80):
        if xbmc.getCondVisibility("Window.IsActive(yesnodialog)"):
            # DialogConfirm control 11 is the affirmative button. SendClick targets that exact
            # window/control pair and cannot activate a different Kodi screen accidentally.
            xbmc.executebuiltin("SendClick(10100,11)")
        if xbmc.getSkinDir() == "skin.duskmate" and not xbmc.getCondVisibility("Window.IsActive(yesnodialog)"):
            return True
        if monitor.waitForAbort(0.25):
            return False
    return False


def _deploy(include_trakt=False, skin_only=False, return_package=DUSKMATE_ANDROID_PACKAGE):
    monitor = xbmc.Monitor()
    # Kodi leaves the Install-from-ZIP file browser open after the repository
    # has been approved. That modal blocks InstallAddon built-ins even while
    # Kodi is in the background, so close only that dialog before deployment.
    xbmc.executebuiltin("Dialog.Close(filebrowser,true)")
    monitor.waitForAbort(0.5)
    # The repository service starts while Kodi owns the foreground, so Android permits this
    # immediate hand-off. Keep Duskmate's progress screen visible while Kodi performs the
    # approved installation in its background process.
    return_to_package(return_package)
    monitor.waitForAbort(1)
    xbmc.log("Duskmate repository: installing approved embedded packages", xbmc.LOGINFO)

    if not skin_only:
        for addon_id, minimum_version in OFFICIAL_DEPENDENCIES:
            if not ensure_official_dependency(addon_id, minimum_version, monitor):
                xbmc.log(
                    "Duskmate repository: official dependency unavailable: {}".format(addon_id),
                    xbmc.LOGERROR,
                )
                return

    packages = EMBEDDED_DEPENDENCIES + (ADDONS[:1] if skin_only else ADDONS)
    if include_trakt:
        packages += (TRAKT_ADDON,)
    for addon_id, expected_version in packages:
        if monitor.abortRequested():
            return
        if not ready(addon_id, expected_version):
            if not install(addon_id, expected_version, monitor):
                xbmc.log("Duskmate repository: installation timed out for {}".format(addon_id), xbmc.LOGERROR)
                return
        if not wait_for(addon_id, expected_version, monitor):
            xbmc.log("Duskmate repository: installation timed out for {}".format(addon_id), xbmc.LOGERROR)
            return
        if addon_id == "skin.duskmate" and not activate_skin(monitor):
            xbmc.log("Duskmate repository: Duskmate skin activation failed", xbmc.LOGERROR)
            return

    parent = os.path.dirname(MARKER)
    if not xbmcvfs.exists(parent):
        xbmcvfs.mkdirs(parent)
    marker = xbmcvfs.File(MARKER, "w")
    marker.write("complete\n")
    marker.close()
    xbmc.log(
        "Duskmate repository: skin and helper deployment complete{}".format(
            "; Trakt sync included" if include_trakt else ""
        ),
        xbmc.LOGINFO,
    )


def deploy(force=False, include_trakt=False, skin_only=False, return_package=DUSKMATE_ANDROID_PACKAGE):
    if os.path.exists(MARKER) and not force:
        return

    window = xbmcgui.Window(10000)
    if window.getProperty(RUNNING_PROPERTY) == "true":
        return
    window.setProperty(RUNNING_PROPERTY, "true")
    try:
        _deploy(include_trakt=include_trakt, skin_only=skin_only, return_package=return_package)
    finally:
        window.clearProperty(RUNNING_PROPERTY)
        # Kodi is the foreground app, so Android permits this hand-off even when Android would
        # reject a background activity launch made directly by Duskmate itself.
        return_to_package(return_package)


if __name__ == "__main__":
    if sys.argv and sys.argv[0].startswith("plugin://"):
        # Files.GetDirectory selects this extension deterministically and supplies a valid plugin
        # handle. Addons.ExecuteAddon is ambiguous for this repository/service/script/plugin and
        # can invoke the plugin extension without a directory handle, crashing Kodi when the
        # directory is closed. Keep every externally callable route on a plugin URL instead.
        # Kodi keeps the base plugin URL in argv[0] and the query string in argv[2].
        # Join the request pieces so routing works both for Files.GetDirectory and direct calls.
        plugin_request = " ".join([sys.argv[0]] + sys.argv[2:])
        if "return_launcher=1" in plugin_request:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=False)
            xbmc.Monitor().waitForAbort(0.25)
            xbmc.executebuiltin("StartAndroidActivity({})".format(DUSKMATE_LAUNCHER_PACKAGE))
        elif "setup_launcher=1" in plugin_request:
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=False)
            # Run in this already-authorized plugin process. Queueing a second RunScript from a
            # Files.GetDirectory callback is dropped by some Android/Kodi builds after the plugin
            # directory closes, leaving the caller waiting forever with no deployment process.
            deploy(force=True, skin_only=True, return_package=DUSKMATE_LAUNCHER_PACKAGE)
        elif "return=1" in plugin_request:
            # Close the plugin directory before switching activities. Kodi serializes native
            # JSON-RPC work behind this call; leaving it open while Android pauses Kodi can pin
            # port 9090 until the process is restarted. The explicit VIEW deep link below is
            # immediate and does not need the old post-directory delay.
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=False)
            return_to_duskmate()
        else:
            trakt = "trakt=1" in plugin_request
            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=False)
            deploy(force=True, include_trakt=trakt)
    elif "return_launcher" in sys.argv[1:]:
        xbmc.executebuiltin("StartAndroidActivity({})".format(DUSKMATE_LAUNCHER_PACKAGE))
    elif "return" in sys.argv[1:]:
        # Kodi owns the foreground here, so Android allows this hand-off even on
        # TV firmware that blocks Duskmate from moving its own background task.
        return_to_duskmate()
    elif "force" in sys.argv[1:] or "trakt" in sys.argv[1:] or "skin" in sys.argv[1:]:
        # Deployment is an explicit user-approved setup action. The repository's login service
        # must remain passive: silently deploying on every new version marker races launcher and
        # app cold starts, changes the foreground, and can trigger concurrent Kodi plugin calls.
        launcher = "launcher" in sys.argv[1:]
        deploy(
            force="force" in sys.argv[1:],
            include_trakt="trakt" in sys.argv[1:],
            skin_only="skin" in sys.argv[1:],
            return_package=DUSKMATE_LAUNCHER_PACKAGE if launcher else DUSKMATE_ANDROID_PACKAGE,
        )
