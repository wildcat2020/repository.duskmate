"""One-shot deployment approved by installing the Duskmate repository ZIP."""

import hashlib
import os
import sys
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs


ADDONS = (
    ("plugin.video.duskmate", "6.21.5.17"),
    ("script.module.duskmate.sync.trakt", "1.2.9.8"),
    ("skin.duskmate", "0.3.2"),
)
MARKER = xbmcvfs.translatePath(
    "special://profile/addon_data/repository.duskmate/bootstrap-1.0.28.done"
)
RUNNING_PROPERTY = "Duskmate.RepositoryDeploymentRunning"
PACKAGE_BASE = (
    "https://raw.githubusercontent.com/wildcat2020/repository.duskmate/"
    "main/omega/zips"
)
PACKAGE_HASHES = {
    ("plugin.video.duskmate", "6.21.5.17"): "209a377fdd20276f79b9d7644a1ae4ddb6a29439f4ed8d9e4e1a5a64c2d4e8cd",
    ("script.module.duskmate.sync.trakt", "1.2.9.8"): "7841c55db5127b6bb265319e3bf18ba027e6e4cc9ef9ace83ba88a955e86de3e",
    ("skin.duskmate", "0.3.2"): "a71628900371df05d69f81b893fe9b315856c392fb4422e7ae2130fd03de78b1",
}


def installed(addon_id):
    return xbmc.getCondVisibility("System.HasAddon({})".format(addon_id))


def installed_version(addon_id):
    try:
        # System.HasAddon is false for an installed but disabled add-on. Read its metadata
        # directly so migrations do not mistake an older disabled build for a clean install.
        return xbmcaddon.Addon(addon_id).getAddonInfo("version")
    except RuntimeError:
        return ""


def ready(addon_id, expected_version):
    return installed_version(addon_id) == expected_version


def wait_for(addon_id, expected_version, monitor, seconds=180):
    for _ in range(seconds * 2):
        if ready(addon_id, expected_version):
            return True
        if monitor.waitForAbort(0.5):
            return False
    return False


def migrate_existing(addon_id, current_version, expected_version, monitor):
    """Replace an older Duskmate package after verifying its exact published archive.

    Kodi's InstallAddon builtin installs missing packages but is not a forced-update API for an
    already installed (especially disabled) add-on. Clean installs still use Kodi's installer and
    dependency resolver; this path is only for a known older Duskmate package.
    """
    expected_hash = PACKAGE_HASHES.get((addon_id, expected_version))
    if not current_version or not expected_hash:
        return False
    filename = "{}-{}.zip".format(addon_id, expected_version)
    url = "{}/{}/{}".format(PACKAGE_BASE, addon_id, filename)
    archive_path = xbmcvfs.translatePath("special://temp/duskmate-{}".format(filename))
    addons_path = os.path.realpath(xbmcvfs.translatePath("special://home/addons"))
    xbmc.log(
        "Duskmate repository: securely migrating {} from {} to {}".format(
            addon_id, current_version, expected_version
        ),
        xbmc.LOGINFO,
    )
    try:
        if not xbmcvfs.copy(url, archive_path):
            raise RuntimeError("download failed")
        digest = hashlib.sha256()
        with open(archive_path, "rb") as source:
            for block in iter(lambda: source.read(1024 * 1024), b""):
                digest.update(block)
        if digest.hexdigest() != expected_hash:
            raise RuntimeError("SHA-256 mismatch")
        prefix = addon_id + "/"
        with zipfile.ZipFile(archive_path, "r") as package:
            for member in package.infolist():
                name = member.filename.replace("\\", "/")
                target = os.path.realpath(os.path.join(addons_path, *name.split("/")))
                if not name.startswith(prefix) or os.path.commonpath((addons_path, target)) != addons_path:
                    raise RuntimeError("unsafe package path")
            package.extractall(addons_path)
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("EnableAddon({})".format(addon_id))
        return wait_for(addon_id, expected_version, monitor, seconds=30)
    except Exception as exc:  # Kodi must keep running and report a useful installer error.
        xbmc.log(
            "Duskmate repository: secure migration failed for {}: {}".format(addon_id, exc),
            xbmc.LOGERROR,
        )
        return False
    finally:
        if xbmcvfs.exists(archive_path):
            xbmcvfs.delete(archive_path)


def install(addon_id, expected_version, monitor, seconds=360):
    current = installed_version(addon_id) or "not installed"
    xbmc.log(
        "Duskmate repository: installing/updating {} from {} to {}".format(
            addon_id, current, expected_version
        ),
        xbmc.LOGINFO,
    )
    if current != "not installed" and migrate_existing(addon_id, current, expected_version, monitor):
        return True
    # Kodi resolves and downloads each add-on's complete dependency chain before
    # System.HasAddon becomes true. On slower Android TV hardware the helper and
    # skin can legitimately take several minutes, especially on the first run.
    # UpdateAddonRepos is asynchronous; retrying this idempotent request also
    # covers the short period where Kodi has installed the repository but has
    # not indexed its add-ons yet.
    for tick in range(seconds * 4):
        if tick % 120 == 0:
            xbmc.executebuiltin("InstallAddon({})".format(addon_id))
        if ready(addon_id, expected_version):
            return True
        if xbmc.getCondVisibility("Window.IsActive(yesnodialog)"):
            # InstallAddon deliberately focuses No. The viewer already approved this narrowly
            # scoped deployment with Duskmate's Install button, so accept Kodi's own dialog.
            xbmc.executebuiltin("Action(Left)")
            monitor.waitForAbort(0.25)
            xbmc.executebuiltin("Action(Select)")
        if monitor.waitForAbort(0.25):
            return False
    return False


def _deploy():
    monitor = xbmc.Monitor()
    # Kodi leaves the Install-from-ZIP file browser open after the repository
    # has been approved. That modal blocks InstallAddon built-ins even while
    # Kodi is in the background, so close only that dialog before deployment.
    xbmc.executebuiltin("Dialog.Close(filebrowser,true)")
    monitor.waitForAbort(0.5)
    # The repository service starts while Kodi owns the foreground, so Android permits this
    # immediate hand-off. Keep Duskmate's progress screen visible while Kodi performs the
    # approved installation in its background process.
    xbmc.executebuiltin("StartAndroidActivity(com.expansionkit.tv)")
    monitor.waitForAbort(1)
    xbmc.log("Duskmate repository: refreshing repository indexes", xbmc.LOGINFO)
    # Never wait on the repository refresh: Kodi can already be refreshing immediately after the
    # ZIP upgrade, and two synchronous refreshes deadlock each other on some Android builds.
    xbmc.executebuiltin("UpdateAddonRepos")
    monitor.waitForAbort(4)

    for addon_id, expected_version in ADDONS:
        if monitor.abortRequested():
            return
        if not ready(addon_id, expected_version):
            if not install(addon_id, expected_version, monitor):
                xbmc.log("Duskmate repository: installation timed out for {}".format(addon_id), xbmc.LOGERROR)
                return
        if not wait_for(addon_id, expected_version, monitor):
            xbmc.log("Duskmate repository: installation timed out for {}".format(addon_id), xbmc.LOGERROR)
            return

    parent = os.path.dirname(MARKER)
    if not xbmcvfs.exists(parent):
        xbmcvfs.mkdirs(parent)
    marker = xbmcvfs.File(MARKER, "w")
    marker.write("complete\n")
    marker.close()
    xbmc.log("Duskmate repository: helper, Trakt sync and skin deployment complete", xbmc.LOGINFO)


def deploy(force=False):
    if os.path.exists(MARKER) and not force:
        return

    window = xbmcgui.Window(10000)
    if window.getProperty(RUNNING_PROPERTY) == "true":
        return
    window.setProperty(RUNNING_PROPERTY, "true")
    try:
        _deploy()
    finally:
        window.clearProperty(RUNNING_PROPERTY)
        # Kodi is the foreground app, so Android permits this hand-off even when Android would
        # reject a background activity launch made directly by Duskmate itself.
        xbmc.executebuiltin("StartAndroidActivity(com.expansionkit.tv)")


if __name__ == "__main__":
    if sys.argv and sys.argv[0].startswith("plugin://"):
        # Files.GetDirectory selects this extension deterministically. ExecuteAddon is ambiguous
        # for an add-on that is simultaneously a repository, service and script and can return OK
        # without running Python. Start the script by its exact path, then release JSON-RPC at once.
        xbmc.executebuiltin(
            "RunScript(special://home/addons/repository.duskmate/service.py,force)"
        )
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=False)
    elif "return" in sys.argv[1:]:
        # Kodi owns the foreground here, so Android allows this hand-off even on
        # TV firmware that blocks Duskmate from moving its own background task.
        xbmc.executebuiltin("StartAndroidActivity(com.expansionkit.tv)")
    else:
        deploy(force="force" in sys.argv[1:])
